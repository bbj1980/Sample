import { Component, ViewChild } from '@angular/core';
import { AngularFirestore } from 'angularfire2/firestore';
import { AngularFireStorage } from 'angularfire2/storage';
import { Observable } from 'rxjs';
import { AngularFireStorageReference, AngularFireUploadTask } from 'angularfire2/storage';
import {ImageDetail} from './image.model';
import { Alert } from 'selenium-webdriver';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers:[ImageDetail]
})
export class AppComponent {
  uploadProgress: Observable<number>;
  posts;
  images;
  image = null;
  zipObject = null;
  ref: AngularFireStorageReference;
  task: AngularFireUploadTask;
  @ViewChild('myImage') myImage;
  uploadError = '';
  isPreviewVisibel = false;
  constructor(private db: AngularFirestore, private storage: AngularFireStorage,private imgDetail: ImageDetail) {

  }
  ngOnInit(): void {
    // Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    // Add 'implements OnInit' to the class.
    this.images = {};
    this.db.collection('ImageTask', ref => ref.limit(10)).snapshotChanges().subscribe((next) => {
      this.images = {};
      this.posts = [];
      next.forEach(post => {
        const obj = post.payload.doc.data();
        obj['id'] = post.payload.doc.id;

        this.loadImage(post.payload.doc.id, obj);
      });
    });
  }
  imageChanged(event) {
    if (!event.target.files.length) {
      this.image = null;
      return;
    }

    const reader = new FileReader();
    this.image = event.target.files[0];

    reader.onload = (e) => {
      this.myImage.nativeElement.src = e.target['result'];
    };
    reader.readAsDataURL(event.target.files[0]);

    const filesize = ((this.image.size / 1024) / 1024); // MB
    if (filesize > 2) {
      this.uploadError = `File too large, max size is 2 MB but yours is ${Number(filesize).toFixed(2)} MB.`;
    } else {
      this.uploadError = '';
      this.isPreviewVisibel =true;
    }
  }
ZipObjectChanged(event) {
    if (!event.target.files.length) {
      this.image = null;
      return;
    }

   // const reader = new FileReader();
    this.zipObject = event.target.files[0];

    // reader.onload = (e) => {
    //   this.myImage.nativeElement.src = e.target['result'];
    // };
    // reader.readAsDataURL(event.target.files[0]);

    // const filesize = ((this.image.size / 1024) / 1024); // MB
    // if (filesize > 2) {
    //   this.uploadError = `File too large, max size is 2 MB but yours is ${Number(filesize).toFixed(2)} MB.`;
    // } else {
    //   this.uploadError = '';
    //   this.isPreviewVisibel =true;
    // }
  }
  submit() {

    const now = new Date();
    const nowUtc = new Date(Date.UTC(now.getUTCFullYear(),
      now.getUTCMonth(), now.getUTCDate(),
      now.getUTCHours(), now.getUTCMinutes(),
      now.getUTCSeconds()));
      this.imgDetail.documentid = '1';
      this.imgDetail.userid = 'MyImage';
    this.db.collection(`ImageTask/`).add({ userid:  this.imgDetail.userid,
                                          documentid: this.imgDetail.documentid  }).then(docRef => {
      this.storage.upload(`posts/${docRef.id}`, this.image).then(() => {
       // this.myImage.nativeElement.src = '#';
              this.storage.upload(`posts/${docRef.id}`, this.zipObject).then(() => {
                alert('Updated Succesfully');
          });

      });
      //_this.ngOnInit();
    }, err => {
      console.error(err);
    });
  }
  delete(downloadUrl) {
    const _this=this;
    // Create a reference to the file to delete
    const desertRef = this.storage.ref(`posts/${downloadUrl}`);
    // Delete the file
    desertRef.delete().subscribe(function () {
      // File deleted successfully
      alert('Success !!!');
      _this.ngOnInit();
    });
  }
  loadImage(post, obj) {
    const ref = this.storage.ref(`posts/${post}`);
    ref.getMetadata().toPromise().then(data => {
      this.posts.push(obj);
      this.images[post] = ref.getDownloadURL();
    }, err => {
      console.error(err);
    });
  }
}
