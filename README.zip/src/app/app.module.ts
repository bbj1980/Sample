import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatButtonModule, MatCardModule } from '@angular/material';
import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireStorageModule } from 'angularfire2/storage';
import { AngularFireAuthModule } from 'angularfire2/auth';


const config = {
  apiKey: 'AIzaSyCYc_m1ml_1MkqVdfebEnZ42Czj-XPdC9k',
    authDomain: 'easiofy-9dbd2.firebaseapp.com',
    databaseURL: 'https://easiofy-9dbd2.firebaseio.com',
    projectId: 'easiofy-9dbd2',
    storageBucket: 'easiofy-9dbd2.appspot.com',
    messagingSenderId: '370140001355',
    appId: '1:370140001355:web:7f5d907b9934699469c9ce',
    measurementId: 'G-PNXYKCZSP7'
};

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AngularFireModule.initializeApp(config),
    BrowserAnimationsModule,
    AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireStorageModule,
    MatButtonModule,
    MatCardModule,
  ],
  providers: [],
  entryComponents: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
