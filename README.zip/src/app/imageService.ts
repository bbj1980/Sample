import { Injectable } from '@angular/core';
import { ImageDetail } from './image.model';
import { AngularFireDatabase,AngularFireList } from 'angularfire2/database';
import {Observable} from 'rxjs';
@Injectable()
export class ImageService {
  images: AngularFireList<ImageDetail>;

  constructor(private database: AngularFireDatabase) {
    this.images = database.list('images');
  }

  getimages(){
    return this.images;
  }

  addimage(newimage: ImageDetail) {
    this.images.push(newimage);
  }

  getimageById(imageId: number){

  }

}
