export class ImageDetail {
  documentid = '';
  userid = '';
}
